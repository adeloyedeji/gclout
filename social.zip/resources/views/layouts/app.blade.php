<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <title>{{ config('app.name', 'Laravel') }} @yield('page-title')</title>
    <!-- Bootstrap core CSS -->
    <link rel="icon" href="{{ asset('img/favicon.png') }}" type="image/gif" sizes="16x16">
    <link href="{{ asset('css/font-awesome.min.css') }}" rel="stylesheet">
    <link href="{{ asset('css/animate.min.css') }}" rel="stylesheet">
    <link href="{{ asset('css/timeline.css') }}" rel="stylesheet">
    <link href="{{ asset('css/cover.css') }}" rel="stylesheet">
    <link href="{{ asset('css/forms.css') }}" rel="stylesheet">
    <link href="{{ asset('css/buttons.css') }}" rel="stylesheet">
    <link href="{{ asset('css/datepicker3.css') }}" rel="stylesheet">
    <link href="{{ asset('css/themes/bootstrap.css') }}" rel="stylesheet">
    @if( active('profiles/clout-profile-edit') )
    <link href="{{ asset('css/edit_profile.css') }}" rel="stylesheet">
    @elseif( active('friends/*') || active('clouts/*') )
    <link href="{{ asset('css/friends.css') }}" rel="stylesheet">
    @elseif( active('posts/photos'))
    <link href="{{ asset('css/photos2.css') }}" rel="stylesheet">
    @elseif( active('notifications/me') || active('notifications/clout-requests') )
    <link href="{{ asset('css/list_posts.css') }}" rel="stylesheet">
    @elseif( active('messages/me') )
    <link href="{{ asset('css/messages1.css') }}" rel="stylesheet">
    @elseif( active('intro/know-your-leaders') )
    <link href="{{ asset('css/profile2.css') }}" rel="stylesheet">
    @endif
    <link href="{{ asset('css/gclout.css') }}" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <script>
        window.Laravel = {!! 
            json_encode([
                'csrfToken' => csrf_token(),
                'url'  =>  'gclout'
            ]); 
        !!}
    </script>
    <style>
        .txt-wrap {
            float: right;
            margin: 10px;
        }
        .txt-wrap-left {
            float: left;
            margin: 10px;
        }
    </style>
    <script src="{{ asset('js/autocomplete.min.js') }}"></script>
</head>
<body class="animated fadeIn">
    <div id="app">
        <nav class="navbar navbar-white navbar-fixed-top" style="height:50px;">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="{{ route('home') }}">
                        <img class="img-circle app-logo" src="{{ asset('img/GCCL.png') }}" style="width:40px;height:40px;margin-top:-20px;">
                    </a>
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-right" style="margin-top:-10px;">
                        <li>
                            <search></search>
                        </li>
                        @auth
                        <li>
                            <a href="{{ route('profile', ['username' => \Auth::user()->username]) }}" title="Profile">
                                Profile
                            </a>
                        </li>
                        <li>
                            <a href="#" title="Notifications">
                                <i class="fa fa-bell"></i>
                                <span class="label label-info pull-right r-activity">
                                    {{ count(\Auth::user()->unreadNotifications) }}
                                </span>
                            </a>
                        </li>
                        <li>
                            <a href="#" title="Clout Requests" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                <i class="fa fa-user-plus"></i>
                                <span class="label label-info pull-right r-activity">
                                    @if (count(\Auth::user()->pending_friends_requests()) > 0)
                                        {{ count(\Auth::user()->pending_friends_requests()) }}
                                    @endif
                                </span>
                            </a>
                            <ul class="dropdown-menu" style="width: 320px;background-color:whitesmoke">
                                
                            </ul>
                        </li>
                        <li>
                            <a href="{{ route('logout') }}" onclick="event.preventDefault();document.getElementById('logout-form').submit();" title="Sign out">
                                    <i class="fa fa-sign-out"></i>
                            </a>
                            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                {{ csrf_field() }}
                            </form>
                        </li>
                        @endauth
                    </ul>
                </div>
            </div>
        </nav>

        @yield('content')
        @auth
        <init></init>
        <notification :id="{{ Auth::id() }}"></notification>
        <audio id="noty_audio">
            <source src="{{ asset('audio/notify.mp3') }}">
            <source src="{{ asset('audio/notify.ogg') }}">
            <source src="{{ asset('audio/notify.wav') }}">
        </audio>
        @endauth
    </div>

    <footer class="footer">
        <div class="container">
        <p class="text-muted"> Copyright &copy; Sprucecities - All rights reserved </p>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}"></script>
    @auth
    <script type="text/javascript">
        $(function() {
            Noty.overrideDefaults({
                theme: 'bootstrap-v3',
                closeWith: ['click', 'button'],
            });
        });
        @if (Session::has('success'))
            new Noty({
                type: 'success',
                layout: 'bottomLeft',
                text: '{{ Session::get("success") }}'
            }).show();
        @endif
    </script>
    @endauth

    <script src="{{ asset('js/bootstrap-datepicker.js') }}"></script>
    @if( active('home') )
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCWT3Ts0ojgLU8RXYIlt-ysZF1N28bmjLs&libraries=places&callback=initializeMap" async defer></script>
        <script>
            function initializeMap()
            {
                //console.log("Map initialized.");
                var input = document.getElementById("locationBox");
                var autoComplete = new google.maps.places.Autocomplete(input);
            }
        </script>
    @endif
</body>
</html>
