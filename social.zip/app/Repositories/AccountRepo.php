<?php
namespace App\Repositories;

use Illuminate\Support\Facades\DB;

use App\Repositories\Interfaces\AccountInterface;

class AccountRepository implements AccountInterface 
{
	
}