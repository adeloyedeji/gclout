<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LikeController extends Controller
{
    public function like($post_id) {
        $post = \App\Post::find($post_id);

        $like = \App\Like::create([
            'user_id'   =>  \Auth::id(),
            'post_id'   =>  $post->id
        ]);

        return \App\Like::find($like->id);
    }

    public function unlike($post_id) {
        $post = \App\Post::find($post_id);
        $like = \App\Like::where('user_id', \Auth::id())
                         ->where('post_id', $post->id)
                         ->first();
        //$id = $like->id;
        $like->delete();
        return $like->id;
    }
}
