<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PhotosController extends Controller
{
    public function index($username) {
        $photos = [];
        $user   =   \App\User::where('username', $username)->first();
        $posts =   $user->posts;
        dd($posts);

        foreach($posts as $post):
            array_push($photos, $post);
        endforeach;

        dd($photos);

        return view('photos.index', [
            'user'      =>  $user,
            'photos'    =>  $photos,
        ]);
    }
}
