<?php
namespace App\Repositories\Interfaces;

interface EventInterface 
{
	
}